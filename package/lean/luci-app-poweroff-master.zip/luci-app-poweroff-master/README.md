# Shut Down Your Router
[![GitHub](https://img.shields.io/github/license/esirplayground/luci-app-poweroff?label=LICENSE&logo=github&logoColor=%20)](https://github.com/esirplayground/luci-app-poweroff/blob/master/LICENSE)
![GitHub Stars](https://img.shields.io/github/stars/esirplayground/luci-app-poweroff.svg?style=flat&logo=appveyor&label=Stars&logo=github)
![GitHub Forks](https://img.shields.io/github/forks/esirplayground/luci-app-poweroff.svg?style=flat&logo=appveyor&label=Forks&logo=github)
